import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
  ));}
  class Home extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          backgroundColor:Colors.white,
        title: Text("Gallery",
          style: TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.bold,
            color: Colors.grey[700],
          ),
        ),
      centerTitle: true,
      ),
        body: GridView.count(
            crossAxisCount:2,
        crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children:List.generate(100, (index) {
            return Container(
              color: Colors.white,
              child: Image.asset('assets/images.png'),
            );
          }),
        ),
      );
    }
  }

